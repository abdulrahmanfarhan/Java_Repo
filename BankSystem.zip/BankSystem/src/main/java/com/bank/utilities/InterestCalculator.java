package com.bank.utilities;

public class InterestCalculator {
    public static double calculate(double balance, double annualInterestRate) {
        return balance * annualInterestRate; // Simple interest
    }
}